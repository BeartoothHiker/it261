<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Basic Arrays</title>
<link href="../../styles/exercises.css" rel="stylesheet" type="text/css">
</head>

<body>
<h1>Storing Multiple Values in an Array</h1>
</body>
</html>