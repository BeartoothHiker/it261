<?php
$flowers = array('tulips', 'roses', 'daffodils', 'orchids', 'daisies');
$flowers2 = ['tulips', 'roses', 'daffodils', 'orchids', 'daisies'];
$flowers[] = 'irises';
$flowers2[] = 'irises';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Basic Arrays</title>
<link href="../../styles/exercises.css" rel="stylesheet" type="text/css">
</head>

<body>
<h1>Storing Multiple Values in an Array</h1>
</body>
</html>