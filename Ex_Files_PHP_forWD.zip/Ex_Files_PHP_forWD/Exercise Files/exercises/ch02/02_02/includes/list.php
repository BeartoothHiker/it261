<ul>
    <li>include</li>
    <li>require</li>
    <li>include_once</li>
    <li>require_once</li>
</ul>