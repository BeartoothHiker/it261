<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Server-Side Includes</title>
<link href="../../styles/exercises.css" rel="stylesheet" type="text/css">
</head>

<body>
<h1>Another Page
</h1>
<?php include 'includes/external.php'; ?>
<p>This one is in the original HTML. <a href="page01.php">Back to page 1</a>.</p>
</body>
</html>