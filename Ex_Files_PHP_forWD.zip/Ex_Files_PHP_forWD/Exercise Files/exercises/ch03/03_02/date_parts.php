<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Using Date Parts</title>
<link href="../../styles/exercises.css" rel="stylesheet" type="text/css">
</head>

<body>
<h1>Using Date Parts to Control Output</h1>
<p>Today is . The time is now .</p>
<p>Good morning.</p>
<p>Good afternoon.</p>
<p>Good evening.</p>
<p>It's late at night.</p>
</body>
</html>