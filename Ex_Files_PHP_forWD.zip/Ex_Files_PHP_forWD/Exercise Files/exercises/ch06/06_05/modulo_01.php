<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Modulo Division</title>
<link href="../../styles/exercises.css" rel="stylesheet" type="text/css">
</head>

<body>
<h1>Calculating the Remainder of a Division</h1>
<p>0 % 4 = <?php echo 0 % 4; ?></p>
<p>1 % 4 = <?php echo 1 % 4; ?></p>
<p>2 % 4 = <?php echo 2 % 4; ?></p>
<p>3 % 4 = <?php echo 3 % 4; ?></p>
<p>4 % 4 = <?php echo 4 % 4; ?></p>
<p>5 % 4 = <?php echo 5 % 4; ?></p>
</body>
</html>