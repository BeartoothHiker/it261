<?php
$original = 'color_Calla_Lilies';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Substring functions</title>
<link href="../../styles/exercises.css" rel="stylesheet" type="text/css">
</head>

<body>
<h1>Finding and Extracting a Substring</h1>
<p>The position of "color" is .</p>
<p>The position of "Calla" is .</p>
</body>
</html>